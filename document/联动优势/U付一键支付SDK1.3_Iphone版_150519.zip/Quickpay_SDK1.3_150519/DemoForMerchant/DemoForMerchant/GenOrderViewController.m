//
//  GenOrderViewController.m
//  MockMerClient_quickpay
//
//  Created by wangtao on 13-10-15.
//  Copyright (c) 2013年 umpay. All rights reserved.
//

#import "GenOrderViewController.h"


// 订单号
#define ID_TFIELD_ORDERNO 100
// 商户标识
#define ID_TFIELD_MER_CUSTID 101
// 商户标识
#define ID_TFIELD_MER_ID 102
// 支付按钮
#define ID_CONFIRM_BTN 103
// 签约按钮
#define ID_SIGN_BTN 104
// 持卡人姓名
#define ID_TFIELD_CARD_HOLDER 105
// 持卡人身份证号
#define ID_TFIELD_IDENTITY_CODE 106
// 是否允许修改身份证号标志位
#define ID_TFIELD_EDIT_FLAG 107
// 手机号
#define ID_TFIELD_MOBILENO_FLAG 108
//卡类型
#define ID_TFIELD_CARDTYPE_FLAG 109
// 银行简写
#define ID_TFIELD_BANK_FLAG 110
//卡类型
#define ID_TFIELD_CARDID_FLAG 111


@interface GenOrderViewController ()

- (void)onClick:(id)sender;

@end

@implementation GenOrderViewController

-(void)loadView {
    [super loadView];
}


- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    NSLog(@"dealloc");
}

-(void)viewDidLoad {
    [super viewDidLoad];
    [self registerForKeyboardNotifications:YES];

#define HEIGHT_HANG 20.0f
#define HEIGHT_JIANJU 10.0f
#define WIDTH_LABEL 100.0f
#define WIDTH_TEXTFIELD 200.0f

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"订单号：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];
    
    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"订单号"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeNumberPad target:nil tag:ID_TFIELD_ORDERNO];

    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_ORDERNO] setText:@"1505191702916582"];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG  + HEIGHT_JIANJU  + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"手机号码：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG  + HEIGHT_JIANJU  + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"手机号码"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_MOBILENO_FLAG];

    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_MOBILENO_FLAG] setText:@""];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 2 + HEIGHT_JIANJU * 2 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"商户号：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 2 + HEIGHT_JIANJU * 2 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"商户号"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_MER_ID];
    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_MER_ID] setText:@"9996"];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 3 + HEIGHT_JIANJU * 3 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"用户标识：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 3 + HEIGHT_JIANJU * 3 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"用户标识"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_MER_CUSTID];
    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_MER_CUSTID] setText:@"GoodStudy"];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 4 + HEIGHT_JIANJU * 4 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"姓名：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 4 + HEIGHT_JIANJU * 4 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"姓名"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_CARD_HOLDER];
    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_CARD_HOLDER] setText:@""];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 5 + HEIGHT_JIANJU * 5 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"身份证号：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 5 + HEIGHT_JIANJU * 5 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"身份证号"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_IDENTITY_CODE];
    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_IDENTITY_CODE] setText:@""];
    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 6 + HEIGHT_JIANJU * 6 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"编辑标志：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 6 + HEIGHT_JIANJU * 6 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"编辑标志"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_EDIT_FLAG];
    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_EDIT_FLAG] setText:@"1"];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 7 + HEIGHT_JIANJU * 7 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"银行简写：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 7 + HEIGHT_JIANJU * 7 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"银行简写"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_BANK_FLAG];
    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_BANK_FLAG] setText:@""];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 8 + HEIGHT_JIANJU * 8 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"卡类型：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 8 + HEIGHT_JIANJU * 8 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"卡类型"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_CARDTYPE_FLAG];

    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_CARDTYPE_FLAG] setText:@""];

    [self addUILable:self.contentView rect:CGRectMake(20.0f, 30.0f + HEIGHT_HANG * 9 + HEIGHT_JIANJU * 9 + self.statusBarHeight, WIDTH_LABEL, HEIGHT_HANG) text:@"卡号：" color:[UIColor blackColor] size:16 textAlignment:NSTextAlignmentLeft isBold:NO tag:-1];

    [self addUITextField:self.contentView rect:CGRectMake(100.0f, 30.0f + HEIGHT_HANG * 9 + HEIGHT_JIANJU * 9 + self.statusBarHeight, WIDTH_TEXTFIELD, HEIGHT_HANG) size:16 PlaceHolder:@"卡号"textAlignment:NSTextAlignmentLeft bgImage:@"" keyBoard:UIKeyboardTypeDefault target:nil tag:ID_TFIELD_CARDID_FLAG];

    [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_CARDID_FLAG] setText:@""];

    UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setFrame:CGRectMake(10.0f, 360.0f + self.statusBarHeight, self.screenWidth/2 - 10.0f, 60.0f)];
    CALayer *layer = btn.layer;
    [layer setCornerRadius:5.0f];
    [btn setTitle:@"支付测试" forState:(UIControlStateNormal)];
    btn.backgroundColor = [UIColor colorWithRed:78.0/255.0f green:217.0/255.0f blue:100.0f/255.0f alpha:1.0f];

    [[btn titleLabel] setFont:[UIFont systemFontOfSize:24.0f]];
    [[btn titleLabel] setTextColor:[UIColor whiteColor]];
    [btn addTarget:self action:@selector(onClick:) forControlEvents:UIControlEventTouchUpInside];
    [btn setTag:ID_CONFIRM_BTN];
    [self.contentView addSubview:btn];

    UIButton* signBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [signBtn setFrame:CGRectMake(5.0f + self.screenWidth/2, 360.0f + self.statusBarHeight, self.screenWidth/2 - 15.0f, 60.0f)];
    CALayer *signLayer = signBtn.layer;
    [signLayer setCornerRadius:5.0f];
    [signBtn setTitle:@"签约测试" forState:(UIControlStateNormal)];
    signBtn.backgroundColor = [UIColor colorWithRed:78.0/255.0f green:217.0/255.0f blue:100.0f/255.0f alpha:1.0f];

    [[signBtn titleLabel] setFont:[UIFont systemFontOfSize:24.0f]];
    [[signBtn titleLabel] setTextColor:[UIColor whiteColor]];
    [signBtn addTarget:self action:@selector(onClick:) forControlEvents:UIControlEventTouchUpInside];
    [signBtn setTag:ID_SIGN_BTN];
    [self.contentView addSubview:signBtn];

    NSArray* subViews = [self.contentView subviews];

    for (UIView* view in subViews) {
        if ([view isKindOfClass:[UITextField class]]) {
            [(UITextField*)view setBorderStyle:(UITextBorderStyleBezel)];
        }
    }

    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(payResult:) name:@"payResult" object:nil];
}

-(void)payResult:(NSNotification*)notification{

    NSDictionary* info = notification.userInfo;

    NSLog(@"支付签约结果%@ %@ %@",[info valueForKey:@"orderId"],[info valueForKey:@"retCode"],[info valueForKey:@"retMsg"]);
}

-(void)onClick:(id)sender {


    [self.view endEditing:YES];
    NSString *merId = [(UITextField*)[self.view viewWithTag:ID_TFIELD_MER_ID] text];
    NSString *orderNo = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_ORDERNO] text];
    NSString *merCustId = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_MER_CUSTID] text];
    NSString *shortBankName = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_BANK_FLAG] text];
    NSString *cardHolder = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_CARD_HOLDER] text];
    NSString *identityCode = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_IDENTITY_CODE] text];
    NSString *editFlag = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_EDIT_FLAG] text];
    NSString *mobileID = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_MOBILENO_FLAG] text];
    NSString *cardType = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_CARDTYPE_FLAG] text];
    NSString *cardId = [(UITextField*)[self.contentView viewWithTag:ID_TFIELD_CARDID_FLAG] text];
    NSLog(@"orderNo=%@,merCustId=%@,shortBankName=%@,cardHolder=%@,identityCode=%@,editFlag=%@,cardId=%@,cardType=%@", orderNo, merCustId, shortBankName, cardHolder, identityCode, editFlag, cardId,cardType);

    UmpayElements* inPayInfo = [[UmpayElements alloc]init];
    [inPayInfo setIdentityCode:identityCode];
    [inPayInfo setEditFlag:editFlag];
    [inPayInfo setCardHolder:cardHolder];
    [inPayInfo setMobileId:mobileID];
    [inPayInfo setText_cardId:cardId];
    NSInteger tag = [sender tag];
    
    if (tag == ID_CONFIRM_BTN) {

        [Umpay pay:orderNo merCustId:merCustId shortBankName:shortBankName cardType:cardType payDic:inPayInfo rootViewController:self];

    }else{

        NSString *signStr = [NSString stringWithFormat:@"merCustId=%@&merId=%@", [merCustId stringByReplacingOccurrencesOfString:@" " withString:@""], [merId stringByReplacingOccurrencesOfString:@" " withString:@""]];
        NSLog(@"########%@",signStr);
//        RSA 加密验签
//        NSString* sign = [self signRsa:signStr];
        NSString* sign = @"";
//        
        [Umpay sign:merId merCustId:merCustId signInfo:sign shortBankName:shortBankName cardType:cardType payDic:inPayInfo rootViewController:self];

    }
}

@end
