//
//  MainViewController.h
//  MockMerClient_quickpay
//
//  Created by wangtao on 13-10-15.
//  Copyright (c) 2013年 umpay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Umpay.h"

// 标题栏高度
#define TITLE_BAR_HEIGHT 45.0f

@interface MainViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate>

// 屏幕宽度
@property (nonatomic, assign) float screenWidth;
// 屏幕高度
@property (nonatomic, assign) float screenHeight;
// 标题栏高度
@property (nonatomic, assign) float statusBarHeight;
// 内容视图
@property (nonatomic, retain) UIScrollView *contentView;
// gear
@property (nonatomic, retain) UIActivityIndicatorView *loadingView;

//注册键盘监听通知
- (void) registerForKeyboardNotifications:(BOOL)regist;
//键盘弹出回调
- (void) keyboardWasShown:(NSNotification *) notify;
//键盘隐藏回调
- (void) keyboardWasHidden:(NSNotification *) notify;
-(id)addUILable:(UIView *)parent rect:(CGRect)rect text:(NSString *)text color:(UIColor *)color size:(int)size textAlignment:(NSTextAlignment)textAlignment isBold:(BOOL)isBold tag:(int)tag;
-(void)addUITextField:(UIView *)parent rect:(CGRect)rect size:(int)size PlaceHolder:(NSString *)text textAlignment:(NSTextAlignment)textAlignment bgImage:(NSString*)bgImage keyBoard:(UIKeyboardType)keyBoard target:(id)target tag:(int)tag;
@end
