//
//  main.m
//  DemoForMerchant
//
//  Created by wangtao on 13-10-23.
//  Copyright (c) 2013年 umpay. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
