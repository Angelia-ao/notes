//
//  AppDelegate.h
//  DemoForMerchant
//
//  Created by wangtao on 13-10-23.
//  Copyright (c) 2013年 umpay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GenOrderViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
