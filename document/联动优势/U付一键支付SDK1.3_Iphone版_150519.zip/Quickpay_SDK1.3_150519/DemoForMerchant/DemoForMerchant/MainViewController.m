//
//  MainViewController.m
//  MockMerClient_quickpay
//
//  Created by wangtao on 13-10-15.
//  Copyright (c) 2013年 umpay. All rights reserved.
//

#import "MainViewController.h"

// 判断是否是IOS7版本
#define IS_IOS7 [[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0f

// 背景颜色
#define UICOLOR_BG [UIColor colorWithRed:236.0f/255.0f green:239.0f/255.0f blue:242.0f/255.0f alpha:1.0f]

@interface MainViewController ()

// 添加标题栏
- (void)addTitleBarView:(UIView *)parent Rect:(CGRect)rect;
// 点击屏幕关闭键盘方法
-(void)resignAllFirstResponder;

@end

@implementation MainViewController

@synthesize screenWidth = _screenWidth;
@synthesize screenHeight = _screenHeight;
@synthesize statusBarHeight = _statusBarHeight;
@synthesize contentView = _contentView;
@synthesize loadingView = _loadingView;

-(id)init {
    
    if (self = [super init]) {
        
        CGRect appRect = [[UIScreen mainScreen] applicationFrame];
        CGRect boundRect = [[UIScreen mainScreen] bounds];
        
        self.screenWidth = CGRectGetWidth(boundRect);
        // 适配IOS7
        if (IS_IOS7) {
            self.statusBarHeight = CGRectGetMinY(appRect);
            self.screenHeight = CGRectGetHeight(boundRect);
        } else {
            self.statusBarHeight = 0;
            self.screenHeight = CGRectGetHeight(appRect);
        }
    }
    return self;
}

-(void)loadView {

    //初始化当前ViewController的根view
    self.view = [[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, self.screenWidth, self.screenHeight)];
    //设置背景颜色
    self.view.backgroundColor = UICOLOR_BG;
    //初始化内容视图
    
    [self addTitleBarView:self.view Rect:CGRectMake(0.0f, 0.0f, self.screenWidth, self.statusBarHeight + TITLE_BAR_HEIGHT)];
    
    self.contentView = [[UIScrollView alloc] initWithFrame:CGRectMake(0.0f, self.statusBarHeight + TITLE_BAR_HEIGHT, self.screenWidth, self.screenHeight - TITLE_BAR_HEIGHT - self.statusBarHeight)];
    
    //构造scrollView内容区域大小
    self.contentView.contentSize = CGSizeMake(self.screenWidth, self.screenHeight - self.statusBarHeight);
    self.contentView.contentOffset = CGPointMake(0.0f, 0.0f);
    self.contentView.showsVerticalScrollIndicator = NO;
    self.contentView.scrollEnabled = YES;
    
    self.loadingView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    self.loadingView.frame = CGRectMake(self.screenWidth/2 - 25, self.screenHeight/2 - 25, 50, 50);
    [self.view addSubview:self.loadingView];
    
    [self.view addSubview:self.contentView];
    
    //初始化手势监听，用于点击关闭键盘
    UITapGestureRecognizer *tapGr = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(resignAllFirstResponder)];
    tapGr.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tapGr];
}
// 添加标题栏
- (void)addTitleBarView:(UIView *)parent Rect:(CGRect)rect{
    
    UIView *subView = [[UIView alloc] initWithFrame:rect];
    subView.backgroundColor = UICOLOR_BG;
    
    CGRect titleRect = CGRectMake(50.0f, self.statusBarHeight + 8.0f, 200.0f, 30.0f);
    [self addUILable:subView rect:titleRect text:@"一键支付2期测试" color:[UIColor blackColor] size:20 textAlignment:NSTextAlignmentCenter isBold:NO tag:-1];
    [parent addSubview:subView];
}
-(void)addUITextField:(UIView *)parent rect:(CGRect)rect size:(int)size PlaceHolder:(NSString *)text textAlignment:(NSTextAlignment)textAlignment bgImage:(NSString*)bgImage keyBoard:(UIKeyboardType)keyBoard target:(id)target tag:(int)tag{

    UITextField *textField = [[UITextField alloc] initWithFrame:rect];

    textField.font = [UIFont systemFontOfSize:size];
    textField.placeholder = text;

    //清除按钮
    textField.clearButtonMode=UITextFieldViewModeNever;

    textField.textAlignment = textAlignment;

    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

    textField.keyboardType = keyBoard;

    [textField setAutocorrectionType:UITextAutocorrectionTypeNo];

    if (tag>0) {
        textField.tag = tag;
    }

    [textField setDelegate:target];
    [parent addSubview:textField];

    
}

-(id)addUILable:(UIView *)parent rect:(CGRect)rect text:(NSString *)text color:(UIColor *)color size:(int)size textAlignment:(NSTextAlignment)textAlignment isBold:(BOOL)isBold tag:(int)tag{

    UILabel *lable = [[UILabel alloc] initWithFrame:rect];
    lable.textAlignment = NSTextAlignmentLeft;

    if (isBold) {
        lable.font = [UIFont boldSystemFontOfSize:size];
        [UIFont boldSystemFontOfSize:size];

    }else{
        lable.font = [UIFont systemFontOfSize:size];
    }

    [lable setNumberOfLines:0];
    lable.lineBreakMode = UILineBreakModeCharacterWrap;
    lable.text = text;
    lable.textColor = color;
    lable.textAlignment = textAlignment;
    lable.backgroundColor = [UIColor clearColor];
    if (tag>0) {
        lable.tag = tag;
    }

    [parent addSubview:lable];
 
    return lable;
}


-(void)resignAllFirstResponder{
    //注销当前焦点
    [self.view endEditing:YES];
}

//屏幕方向控制
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    
    return (toInterfaceOrientation == UIInterfaceOrientationPortrait);
    
}

//注册/取消键盘监听
- (void) registerForKeyboardNotifications:(BOOL)regist{
    
    if (regist) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasShown:) name:UIKeyboardDidShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWasHidden:) name:UIKeyboardDidHideNotification object:nil];
    } else {
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidShowNotification object:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardDidHideNotification object:nil];
    }
}

//键盘出现事件处理
- (void) keyboardWasShown:(NSNotification *) notify{
    NSDictionary *info = [notify userInfo];
    
    NSValue *value = [info objectForKey:UIKeyboardFrameEndUserInfoKey];
    CGSize keyboardSize = [value CGRectValue].size;
    
    [self.contentView setScrollEnabled:YES];
    [self.contentView setContentOffset:CGPointMake(0.0f, keyboardSize.height - self.screenHeight/2 + 150.0f) animated:NO];
}

//键盘隐藏事件处理
- (void) keyboardWasHidden:(NSNotification *) notify{
    [self.contentView setFrame:CGRectMake(0.0f, self.statusBarHeight + TITLE_BAR_HEIGHT, self.screenWidth, self.screenHeight - TITLE_BAR_HEIGHT - self.statusBarHeight)];
}

-(void)onPayResult:(NSString *)orderId resultCode:(NSString *)resultCode resultMessage:(NSString *)resultMessage {
    
}

@end
