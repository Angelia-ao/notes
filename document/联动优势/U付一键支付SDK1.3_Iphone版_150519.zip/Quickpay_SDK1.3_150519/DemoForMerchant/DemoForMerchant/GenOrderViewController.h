//
//  GenOrderViewController.h
//  MockMerClient_quickpay
//
//  Created by wangtao on 13-10-15.
//  Copyright (c) 2013年 umpay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface GenOrderViewController : MainViewController

@end
