//
//  TestVC.m
//  UmpaySDK-Iphone
//
//  Created by Wang Haijun on 12-8-27.
//  Copyright (c) 2012年 Umpay. All rights reserved.
//

#import "TestVC.h"

@implementation TestVC

//加载视图
- (void)loadView{
    
    CGRect appRect = [[UIScreen mainScreen] applicationFrame];

    
    UIScrollView* view = [[UIScrollView alloc] initWithFrame:appRect];
    
    view.contentSize = appRect.size;
    
    view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"ump_bg_body"]];
    
    self.view = view;
    
    [self loadSubViews];
    
}

//加载子视图
- (void)loadSubViews{
	
    UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 20.0f, 320.0f, 45.0f)];
	[label setText:@"手机支付SDK测试"];
	[label setFont:[UIFont boldSystemFontOfSize:25]];
	[label setTextColor:[UIColor blackColor]];
	[label setTextAlignment:UITextAlignmentCenter];
	[label setBackgroundColor:[UIColor clearColor]];
	[self.view addSubview:label];
    
    //订单号
	UITextField* tf1 = [[UITextField alloc] initWithFrame:CGRectMake(30.0f, 75.0f, 260.0f, 30.0f)];
	[tf1 setBorderStyle:UITextBorderStyleRoundedRect];
	[tf1 setTextAlignment:UITextAlignmentLeft];
	[tf1 setKeyboardType:UIKeyboardTypeNumberPad];
	[tf1 setPlaceholder:@"订单号..."];
	[tf1 setTag:id_tfield_tradeNo];
    [self.view addSubview:tf1];
	
       
    UIButton* btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btn setFrame:CGRectMake(30.0f, 130.0f, 260.0f, 40.0f)];
    [btn setTitle:@"支付测试" forState:(UIControlStateNormal)];
    [btn setTitle:@"支付测试" forState:(UIControlStateHighlighted)];
    
    [[btn titleLabel] setFont:[UIFont systemFontOfSize:20.0f]];
    
    [btn addTarget:self action:@selector(onClick:) forControlEvents:UIControlEventTouchUpInside];
    [btn setTag:id_btn_pay];
    [self.view addSubview:btn];
}

- (void)pay:(NSString*)tradeNo{
    
    if (tradeNo == nil || [@"" isEqual:tradeNo]) {
        
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"请输入正确的订单号" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
		[alert show];
        [alert release];
        
    }else{
        
        [Umpay pay:tradeNo payType:@"9" rootViewController:self.view.window.rootViewController delegate:self launchType:YES];
        
    }

}

//按钮事件处理
- (void)onClick:(id)sender{
    
    [self.view endEditing:YES];
    
    NSString* tradeNo = [(UITextField*)[self.view viewWithTag:id_tfield_tradeNo] text];

    [self pay:tradeNo];
    
}

/**************************************************************/

//支付回调
- (void)onPayResult:(NSString*)orderId resultCode:(NSString*)resultCode resultMessage:(NSString*)resultMessage{
    NSLog(@"orderId:%@,resultCode:%@,resultMessage:%@",orderId,resultCode,resultMessage);
    
    UIAlertView* alert = [[UIAlertView alloc] initWithTitle:resultCode message:resultMessage delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alert show];
    [alert release];
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation{
    
    return (toInterfaceOrientation == UIInterfaceOrientationPortrait);
        
}

- (NSUInteger)supportedInterfaceOrientations{
    
    return UIInterfaceOrientationMaskPortrait;
    
}

- (BOOL)shouldAutorotate{
    
    return YES;
    
}

@end
