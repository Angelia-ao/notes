//
//  AppDelegate.m
//  UmpaySDK
//
//  Created by Wang Haijun on 12-8-27.
//  Copyright (c) 2012年 Umpay. All rights reserved.
//

#import "UmpayAppDelegate.h"

@implementation UmpayAppDelegate

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

	window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];

    [window makeKeyAndVisible];
    
    testVC = [[TestVC alloc] init];
    
    [window addSubview:testVC.view];
    window.rootViewController = testVC;
}

- (void)dealloc {
    [testVC release];
    [window release];
    [super dealloc];
}


@end
