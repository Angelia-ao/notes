//
//  AppDelegate.h
//  UmpaySDK
//
//  Created by Wang Haijun on 12-8-27.
//  Copyright (c) 2012年 Umpay. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TestVC.h"
@interface UmpayAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TestVC* testVC;
}


@end