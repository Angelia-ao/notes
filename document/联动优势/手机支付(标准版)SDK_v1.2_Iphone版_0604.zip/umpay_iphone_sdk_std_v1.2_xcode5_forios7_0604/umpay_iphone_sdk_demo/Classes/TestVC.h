//
//  TestVC.h
//  UmpaySDK-Iphone
//
//  Created by Wang Haijun on 12-8-27.
//  Copyright (c) 2012年 Umpay. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Umpay.h"

#define id_tfield_tradeNo 101
#define id_tfield_cardType 102
#define id_tfield_bankName 103

#define id_btn_pay 104

@interface TestVC:UIViewController<UmpayDelegate>{
    
}

- (void)loadSubViews;

- (void)onClick:(id)sender;

@end
